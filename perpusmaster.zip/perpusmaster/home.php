<p></p>
<body>
    <center><font size="+3" face="arial">Sistem Informasi Perpustakaan</font></center>
    <center><font size="+3" face="arial">SMK Muhammadiyah 1 Yogyakarta</font></center>
    <center><font size="-1" face="arial">Copyright 2020 | WEB DESIGN by Nasaka XIIRPL</font></center>
</body>